## Packages
recharts | Data visualization for inventory health and pipeline stats
date-fns | Formatting dates for logs and order history

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  mono: ["JetBrains Mono", "monospace"],
}
